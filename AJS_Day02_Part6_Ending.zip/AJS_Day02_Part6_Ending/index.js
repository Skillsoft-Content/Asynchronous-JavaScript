import async from 'async';
//
async.parallel([
  (cb) => {
    setTimeout(() => {
      console.log('A');
      cb(null, "A Completed");
    }, 2000);
  },
  (cb) => {
    setTimeout(() => {
      console.log('B');
      cb(null, "B Completed");
    }, 500);
  },
  (cb) => {
    setTimeout(() => {
      console.log('C');
      cb(null, "C Completed");
    }, 1000);
  }
], (err, results)=>{
  console.log(results);
});
