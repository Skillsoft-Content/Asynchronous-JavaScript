import { of } from 'rxjs';
//
const greeting = of("Hello", " from ", "Skillsoft!");
let greet = "";
greeting.subscribe(val => {
  greet += val;
});
//
console.log(greet);
