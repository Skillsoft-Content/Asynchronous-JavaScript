let el = document.getElementById("response");
const doFirst = function() {
  //const pf = new Promise((resolve, reject)=>{
  return new Promise((resolve, reject)=>{
    setTimeout(function(){
      resolve("I was first...")
    }, 2000);
  });
  //return pf;			
};
doFirst().then((data)=>{
  el.innerHTML = el.innerHTML + data + "<br />And I am second!";
});
