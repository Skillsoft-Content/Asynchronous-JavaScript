let el = document.getElementById("response");
const doFirst = function() {
  return new Promise((resolve, reject)=>{
    setTimeout(function(){
      //resolve("I was first...");
      reject("An error occured");
    }, 2000);
  });
};
//
async function showMessages(){
  try{
    let firstMessage = await doFirst();
    el.innerHTML = firstMessage + "<br />And I am second!";  
  } catch(err){
    el.innerHTML = "An Error Occured!";  
  }
}
//
showMessages();
