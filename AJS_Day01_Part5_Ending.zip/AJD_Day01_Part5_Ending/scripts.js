let el = document.getElementById("response");
//
async function showData(){
  try{
    const postData = await fetch('https://jsonplaceholder.typicode.com/posts/1');
    const finalData = await postData.json();
    el.innerHTML = finalData.title;  
  }catch(err){
    el.innerHTML = "Oops " + err;  
  }
};
//
/* 
function showData(){
  fetch('https://jsonplaceholder.typicode.com/posts/1')
  .then((data)=>{
    return(data.json())
  })
  .then((data)=>{
    return(data);
  })
  .then((post)=>{
    el.innerHTML = post.title;
  })
  .catch(err => {
    el.innerHTML = err;
  })
};
 */