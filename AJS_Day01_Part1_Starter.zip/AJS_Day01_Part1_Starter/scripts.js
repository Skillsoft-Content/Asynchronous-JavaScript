//if you want to use just the console window, just uncomment that line
//and comment the lines that use the DOM element
let el = document.getElementById("response");
function A() {
  //console.log("A")
  el.innerHTML = el.innerHTML + "<br />I am function A!";
}
function B() {
  //console.log("B")
  el.innerHTML = el.innerHTML + "<br />I am function B!";
}
function C() {
  //console.log("C")
  el.innerHTML = el.innerHTML + "<br />I am function C!";
}
A();
B();
C();


