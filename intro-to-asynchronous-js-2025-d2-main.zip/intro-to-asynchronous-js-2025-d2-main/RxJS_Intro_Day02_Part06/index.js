import { interval } from 'rxjs';
//
const counter$ = interval(500);
//
let counter = counter$.subscribe((x)=>console.log(x));
//
setTimeout(()=>{
  counter.unsubscribe();
}, 3000);

