let el = document.getElementById("response");
//
async function getData(){
  try{
    const postData = await fetch('https://jsonplaceholder.typicode.com/posts/1');
    const finalData = await postData.json();
    el.innerHTML = finalData.title;  
  }catch(err){
    el.innerHTML = "Oops " + err;  
  }
};
