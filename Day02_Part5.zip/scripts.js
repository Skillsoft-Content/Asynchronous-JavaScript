import { interval } from 'rxjs';
//
const counter$ = interval(500);
//
let counter = counter$.subscribe( x => console.log(x));
//counter.unsubscribe();
setTimeout(()=>{
  counter.unsubscribe();
}, 3000);
