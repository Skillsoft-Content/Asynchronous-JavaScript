import { Observable } from 'rxjs';
//
const observable = new Observable(
  obs => {
    setTimeout(()=>obs.next("hello"),1000);
    setTimeout(()=>obs.next("from"),2000);
    setTimeout(()=>obs.next("Skillsoft"),3000);
    setTimeout(()=>obs.complete(),4000);
  }  
);
//
const observer = {
  next: aValue => console.log(aValue),
  complete : () => console.log("done"),
  error : (err) => console.log("An error occured " + err)
}
//
observable.subscribe(observer);
