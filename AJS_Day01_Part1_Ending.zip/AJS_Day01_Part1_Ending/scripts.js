//Code at END of Part1 on Day1
let el = document.getElementById("response");
function A() {
  console.log("A")
}
function B(cb) {
  setTimeout(() => {
      console.log("B");
      cb();
  }, 2000);    
};
function C() {
  console.log("C")
}
A();
B(C);
//C();


