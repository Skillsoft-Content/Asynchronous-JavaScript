let el = document.getElementById("response");
//
async function getData(){
  try{
    const postData = await fetch('http://localhost:3030/customers');
    const finalData = await postData.json();
    el.innerHTML = finalData[0].username;  
  }catch(err){
    el.innerHTML = "Oops " + err;  
  }
};
