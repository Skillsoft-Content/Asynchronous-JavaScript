let el = document.getElementById("response");
//
async function showData(){
  try{
    const postData = await fetch(
      'http://localhost:3030/employees',
      {
        method:"POST",
        headers: {
          'Content-Type': 'application/json',
        },
        body:JSON.stringify({"username":"Jennifer", "password":"1234"})
      }
    );
    el.innerHTML = JSON.stringify({"username":"Jennifer", "password":"1234"}) ;
  }catch(err){
    el.innerHTML = "Oops " + err;  
  }
};
//
