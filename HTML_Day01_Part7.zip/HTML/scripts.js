let el = document.getElementById("response");
//
async function getData(){
  try{
    const postData = await fetch(
      'http://localhost:3030/customers',
      {
        method:"POST",
        headers: {
          'Content-Type': 'application/json',
        },
        body:JSON.stringify({
          "username":"Jennifer", 
          "password":"1234"
        })
      }
    );
    const finalData = await postData.json();
    el.innerHTML = finalData.id;  
    console.log(finalData.id);
  }catch(err){
    el.innerHTML = "Oops " + err;  
  }
};
