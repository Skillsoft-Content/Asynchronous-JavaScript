import { of, map } from 'rxjs';
//
const observable = new of(
  "Hello",
  "from",
  "Skillsoft"
);
//
observable.pipe(
  map(x => x)
).subscribe({
  next(data) { 
      console.log(data); 
  }, 
  error(err){
      console.log(err)
  },
  complete(){
      console.log("all done")
  }
});


