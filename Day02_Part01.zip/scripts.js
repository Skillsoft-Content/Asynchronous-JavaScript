const pf1 = Promise.resolve("done");
//pf1.then(data=>console.log(data));
//
const pf3 = new Promise((resolve, reject) => {
  setTimeout(resolve, 2000, 2022);
});
//
//const pf2 = Promise.resolve("mee too");
const pf2 = Promise.reject("Error occured!");
//pf2.then(data=>console.log(data));
//
Promise.race([pf1, pf2, pf3])
.then((data)=>{
    console.log(data);
}).catch(err => {
  console.log(err);
});

