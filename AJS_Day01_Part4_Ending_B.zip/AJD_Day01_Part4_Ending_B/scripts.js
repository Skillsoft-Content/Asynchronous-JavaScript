let el = document.getElementById("response");
const doFirst = function() {
  return new Promise((resolve, reject)=>{
    setTimeout(()=>{
      resolve("<br />I was first...");
      //reject("<br />Oops!...");
    }, 1000);      
  });
};
//
doFirst()
.then(
  resolve=>{
    el.innerHTML = resolve + "<br />And I am second!"
  },
  reject => {
     el.innerHTML = "<p style='color:red;'>" + reject + "...check with your Administrator";
  }
);
//
/* 
doFirst().then((data)=>{
    el.innerHTML = data + "<br />And I am second!"
})
.catch(err => {
  //console.log("An error occured!");
  el.innerHTML = "An error occured! " + err;
});
 */
