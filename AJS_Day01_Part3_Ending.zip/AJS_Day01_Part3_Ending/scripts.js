let el = document.getElementById("response");
const doFirst = function() {
  return new Promise((resolve, reject)=>{
    setTimeout(()=>{
      resolve("I was first...");
    },1000);
  });
};
//
async function showMessages(){
  let firstMessage = await doFirst();
  el.innerHTML = firstMessage + "<br />And I am second!";
}
//
showMessages();

